class Attendance {
  final int? id;
  final String timestamp; // 'YYYY-MM-DD HH:MM:SS'
  final String personId;
  final String gate;
  final int rssi;
  final String note;

  Attendance({
    this.id,
    required this.timestamp,
    required this.personId,
    this.gate = 'MainDoor',
    this.rssi = 0,
    this.note = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'timestamp': timestamp,
        'personId': personId,
        'gate': gate,
        'rssi': rssi,
        'note': note,
      };

  factory Attendance.fromMap(Map<String, dynamic> m) => Attendance(
        id: m['id'],
        timestamp: m['timestamp'],
        personId: m['personId'],
        gate: m['gate'] ?? 'MainDoor',
        rssi: m['rssi'] ?? 0,
        note: m['note'] ?? '',
      );
}