import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _pinLockEnabled = false;
  String _pinCode = "";

  final TextEditingController _pinController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Settings"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SwitchListTile(
              title: const Text("Enable PIN Lock"),
              value: _pinLockEnabled,
              onChanged: (val) {
                setState(() {
                  _pinLockEnabled = val;
                  if (!_pinLockEnabled) {
                    _pinCode = "";
                  }
                });
              },
            ),
            if (_pinLockEnabled) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _pinController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Enter PIN",
                ),
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 6,
                onChanged: (val) {
                  setState(() {
                    _pinCode = val;
                  });
                },
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _pinCode.isEmpty
                            ? "PIN not set!"
                            : "PIN set successfully!",
                      ),
                    ),
                  );
                },
                child: const Text("Save PIN"),
              ),
            ],
          ],
        ),
      ),
    );
  }
}