import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

class AppDb {
  static Database? _db;
  static const _dbName = 'attendance.db';
  static const _dbVersion = 1;

  static Future<Database> get instance async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), _dbName);
    _db = await openDatabase(
      path,
      version: _dbVersion,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE people(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            role TEXT,
            active INTEGER NOT NULL DEFAULT 1
          );
        ''');
        await db.execute('''
          CREATE TABLE attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            personId TEXT NOT NULL,
            gate TEXT,
            rssi INTEGER,
            note TEXT
          );
        ''');
        // seed example
        await db.insert('people', {'id':'B001','name':'Asha Patil','role':'Student','active':1});
        await db.insert('people', {'id':'B002','name':'Rahul Shah','role':'Student','active':1});
      },
    );
    return _db!;
  }
}