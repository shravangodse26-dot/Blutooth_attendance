class Person {
  final String id; // e.g., B001
  final String name;
  final String role;
  final bool active;

  Person({required this.id, required this.name, this.role = "", this.active = true});

  Map<String, dynamic> toMap() =>
      {'id': id, 'name': name, 'role': role, 'active': active ? 1 : 0};

  factory Person.fromMap(Map<String, dynamic> m) => Person(
        id: m['id'],
        name: m['name'],
        role: m['role'] ?? '',
        active: (m['active'] ?? 1) == 1,
      );
}