import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/db.dart';
import '../services/csv_importer.dart';
import '../services/excel_exporter.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  List<Map<String, dynamic>> rows = [];

  Future<void> _load() async {
    final db = await AppDb.instance;
    final data = await db.rawQuery('''
      SELECT a.id, a.timestamp, a.personId, IFNULL(p.name,'') as name, a.gate, a.rssi, a.note
      FROM attendance a LEFT JOIN people p ON p.id=a.personId
      ORDER BY a.timestamp DESC, a.id DESC
    ''');
    setState(()=>rows = data);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _importCsv() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv','txt'],
    );
    if (result == null || result.files.isEmpty) return;
    final path = result.files.single.path;
    if (path == null) return;
    final file = File(path);
    final count = await CsvImporter.importAttendanceCsv(file);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Imported $count rows')));
    _load();
  }

  Future<void> _exportExcel() async {
    final f = await ExcelExporter.exportToExcel();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content