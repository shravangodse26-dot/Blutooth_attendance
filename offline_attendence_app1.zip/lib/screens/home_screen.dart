import 'package:flutter/material.dart';
import 'people_screen.dart';
import 'attendance_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Attendance (Offline)')),
      body: Center(
        child: Wrap(
          spacing: 24,
          runSpacing: 24,
          children: [
            _HomeButton(icon: Icons.people, label: 'People', onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>const PeopleScreen()))),
            _HomeButton(icon: Icons.assignment_turned_in, label: 'Attendance', onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>const AttendanceScreen()))),
            _HomeButton(icon: Icons.settings, label: 'Settings', onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>const SettingsScreen()))),
          ],
        ),
      ),
    );
  }
}

class _HomeButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _HomeButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 140,
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 42),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}