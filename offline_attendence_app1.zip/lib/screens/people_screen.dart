import 'package:flutter/material.dart';
import '../services/db.dart';

class PeopleScreen extends StatefulWidget {
  const PeopleScreen({super.key});

  @override
  State<PeopleScreen> createState() => _PeopleScreenState();
}

class _PeopleScreenState extends State<PeopleScreen> {
  List<Map<String, dynamic>> people = [];

  Future<void> _load() async {
    final db = await AppDb.instance;
    final data = await db.query('people', orderBy: 'id ASC');
    setState(() => people = data);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _editPerson({Map<String,dynamic>? person}) async {
    final idCtrl = TextEditingController(text: person?['id'] ?? '');
    final nameCtrl = TextEditingController(text: person?['name'] ?? '');
    final roleCtrl = TextEditingController(text: person?['role'] ?? '');
    bool active = (person?['active'] ?? 1) == 1;
    final created = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(person==null ? 'Add Person' : 'Edit Person'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: idCtrl, decoration: const InputDecoration(labelText: 'ID (e.g., B001)')),
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name')),
              TextField(controller: roleCtrl, decoration: const InputDecoration(labelText: 'Role (optional)')),
              SwitchListTile(value: active, onChanged: (v){ active=v; setState((){}); }, title: const Text('Active')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () async {
            final db = await AppDb.instance;
            if (person==null) {
              await db.insert('people', {'id': idCtrl.text.trim(), 'name': nameCtrl.text.trim(), 'role': roleCtrl.text.trim(), 'active': active?1:0});
            } else {
              await db.update('people', {'name': nameCtrl.text.trim(), 'role': roleCtrl.text.trim(), 'active': active?1:0}, where: 'id=?', whereArgs: [person['id']]);
            }
            Navigator.pop(context,true);
          }, child: const Text('Save')),
        ],
      ),
    );
    if (created==true) _load();
  }

  void _deletePerson(String id) async {
    final ok = await showDialog<bool>(context: context, builder: (_)=>AlertDialog(
      title: const Text('Delete Person'),
      content: Text('Delete $id? This does not remove past attendance.'),
      actions: [
        TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('Cancel')),
        ElevatedButton(onPressed: ()=>Navigator.pop(context,true), child: const Text('Delete'))
      ],
    ));
    if (ok==true) {
      final db = await AppDb.instance;
      await db.delete('people', where: 'id=?', whereArgs: [id]);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('People')),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=>_editPerson(),
        child: const Icon(Icons.add),
      ),
      body: ListView.separated(
        itemCount: people.length,
        separatorBuilder: (_, __)=>const Divider(height:1),
        itemBuilder: (_, i){
          final p = people[i];
          return ListTile(
            title: Text('${p['id']} - ${p['name']}'),
            subtitle: Text('${p['role'] ?? ''}  |  Active: ${(p['active']==1)?'Y':'N'}'),
            onTap: ()=>_editPerson(person: p),
            trailing: IconButton(onPressed: ()=>_deletePerson(p['id']), icon: const Icon(Icons.delete)),
          );
        },
      ),
    );
  }
}