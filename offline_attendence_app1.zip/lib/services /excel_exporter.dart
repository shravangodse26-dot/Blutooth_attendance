import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'db.dart';

class ExcelExporter {
  static Future<File> exportToExcel() async {
    final db = await AppDb.instance;
    final people = await db.query('people');
    final attendance = await db.query('attendance', orderBy: 'timestamp DESC');

    final excel = Excel.createExcel();
    final peopleSheet = excel['People'];
    peopleSheet.appendRow(['ID','Name','Role','Active (Y/N)']);
    for (final p in people) {
      peopleSheet.appendRow([p['id'], p['name'], p['role'] ?? '', (p['active']==1)?'Y':'N']);
    }

    final attSheet = excel['Attendance'];
    attSheet.appendRow(['Timestamp','ID','Name (from People)','Gate','RSSI','Note']);
    final nameMap = {for (final p in people) p['id']: p['name']};
    for (final a in attendance) {
      attSheet.appendRow([
        a['timestamp'],
        a['personId'],
        nameMap[a['personId']] ?? '',
        a['gate'] ?? '',
        a['rssi'] ?? 0,
        a['note'] ?? '',
      ]);
    }

    final dir = await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/Attendance_Export.xlsx');
    await file.writeAsBytes(excel.encode()!);
    return file;
  }
}