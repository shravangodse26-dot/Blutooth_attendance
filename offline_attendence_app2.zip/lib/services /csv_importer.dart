import 'dart:io';
import 'package:csv/csv.dart';
import 'db.dart';

/// Expected CSV header (recommended):
/// Timestamp,ID,Name,Gate,RSSI,Note
class CsvImporter {
  static Future<int> importAttendanceCsv(File file) async {
    final raw = await file.readAsString();
    final rows = const CsvToListConverter(eol: '\n').convert(raw);
    final db = await AppDb.instance;
    int inserted = 0;
    if (rows.isEmpty) return 0;

    // Detect header: if first cell looks like 'Timestamp'
    int startIndex = 0;
    final firstCell = rows[0].isNotEmpty ? rows[0][0].toString() : '';
    final hasHeader = firstCell.toLowerCase().contains('timestamp');
    if (hasHeader) startIndex = 1;

    for (int i = startIndex; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      try {
        final timestamp = row[0].toString();
        final id = row[1].toString();
        final gate = row.length > 3 ? row[3].toString() : 'MainDoor';
        final rssi = row.length > 4 ? int.tryParse(row[4].toString()) ?? 0 : 0;
        final note = row.length > 5 ? row[5].toString() : '';
        await db.insert('attendance', {
          'timestamp': timestamp,
          'personId': id,
          'gate': gate,
          'rssi': rssi,
          'note': note,
        });
        inserted++;
      } catch (_) {
        // ignore bad rows
      }
    }
    return inserted;
  }
}